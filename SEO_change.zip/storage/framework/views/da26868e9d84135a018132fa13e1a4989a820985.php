

    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title><?php echo e(config('app.name')); ?></title>
      <!-- Tell the browser to be responsive to screen width -->
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <!-- Font Awesome -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
      <!-- Ionicons -->
      <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
      <!-- Theme style -->
      <link rel="stylesheet" href="<?php echo e(asset('../../dist/css/adminlte.min.css')); ?> ">
      <!-- Google Font: Source Sans Pro -->
      <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    </head>
    <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="../../index3.html" class="nav-link">Home</a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Contact</a>
          </li>
        </ul>

        <!-- SEARCH FORM -->
        <form class="form-inline ml-3">
          <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-navbar" type="submit">
                <i class="fa fa-search"></i>
              </button>
            </div>
          </div>
        </form>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
          <!-- Messages Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="fa fa-comments-o"></i>
              <span class="badge badge-danger navbar-badge">3</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img src="../../dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Brad Diesel
                      <span class="float-right text-sm text-danger"><i class="fa fa-star"></i></span>
                    </h3>
                    <p class="text-sm">Call me whenever you can...</p>
                    <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img src="../../dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      John Pierce
                      <span class="float-right text-sm text-muted"><i class="fa fa-star"></i></span>
                    </h3>
                    <p class="text-sm">I got your message bro</p>
                    <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <!-- Message Start -->
                <div class="media">
                  <img src="../../dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                  <div class="media-body">
                    <h3 class="dropdown-item-title">
                      Nora Silvester
                      <span class="float-right text-sm text-warning"><i class="fa fa-star"></i></span>
                    </h3>
                    <p class="text-sm">The subject goes here</p>
                    <p class="text-sm text-muted"><i class="fa fa-clock-o mr-1"></i> 4 Hours Ago</p>
                  </div>
                </div>
                <!-- Message End -->
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
            </div>
          </li>
          <!-- Notifications Dropdown Menu -->
          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i class="fa fa-bell-o"></i>
              <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <span class="dropdown-item dropdown-header">15 Notifications</span>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fa fa-envelope mr-2"></i> 4 new messages
                <span class="float-right text-muted text-sm">3 mins</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fa fa-users mr-2"></i> 8 friend requests
                <span class="float-right text-muted text-sm">12 hours</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">
                <i class="fa fa-file mr-2"></i> 3 new reports
                <span class="float-right text-muted text-sm">2 days</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
              <i class="fa fa-th-large"></i>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.navbar -->

      <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="/" class="brand-link">
              <img src=" <?php echo e(asset('../../dist/img/AdminLTELogo.png')); ?>"
                   alt="AdminLTE Logo"
                   class="brand-image img-circle elevation-3"
                   style="opacity: .8">
              <span class="brand-text font-weight-light"><?php echo e(config('app.name')); ?></span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
              <!-- Sidebar user (optional) -->
              <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                  <img src="../../dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
                </div>
                <div class="info">
                  <a href="#" class="d-block"><?php echo e(Auth()->User()->name); ?></a>
                </div>
              </div>

              <!-- Sidebar Menu -->
              <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                  <!-- Add icons to the links using the .nav-icon class
                       with font-awesome or any other icon font library -->
                  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                      <i class="nav-icon fa fa-dashboard"></i>
                      <p>
                        Dashboard
                        <i class="right fa fa-angle-left"></i>
                      </p>
                    </a>
                    <ul class="nav nav-treeview">

                      <li class="nav-item">
                        <a href="home" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Dashboard</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="dashboard" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Analysis</p>
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li class="nav-item">
                    <a href="www.tbxhost.co.uk" class="nav-link">
                      <i class="nav-icon fa fa-th"></i>
                      <p>
                        New Offers
                        <span class="right badge badge-danger">New</span>
                      </p>
                    </a>
                  </li>

                  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                      <i class="nav-icon fa fa-tree"></i>
                      <p>
                        UI Elements
                        <i class="fa fa-angle-left right"></i>
                      </p>
                    </a>
                    <ul class="nav nav-treeview">
                      <li class="nav-item">
                        <a href="../UI/general.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>General</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../UI/icons.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Icons</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../UI/buttons.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Buttons</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../UI/sliders.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Sliders</p>
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                      <i class="nav-icon fa fa-edit"></i>
                      <p>
                        My project
                        <i class="fa fa-angle-left right"></i>
                      </p>
                    </a>
                    <ul class="nav nav-treeview">
                      <li class="nav-item">
                        <a href="projects/create" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Create new Project</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="project" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Active project</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../forms/editors.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>edit project</p>
                        </a>
                      </li>
                    </ul>
                  </li>

                  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                      <i class="nav-icon fa fa-envelope-o"></i>
                      <p>
                        Mailbox
                        <i class="fa fa-angle-left right"></i>
                      </p>
                    </a>
                    <ul class="nav nav-treeview">
                      <li class="nav-item">
                        <a href="../mailbox/mailbox.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Inbox</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../mailbox/compose.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Compose</p>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="../mailbox/read-mail.html" class="nav-link">
                          <i class="fa fa-circle-o nav-icon"></i>
                          <p>Read</p>
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                      <i class="nav-icon fa fa-book"></i>
                      <p>
                        Pages
                        <i class="fa fa-angle-left right"></i>
                      </p>
                    </a>

              </nav>
              <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
          </aside>




      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Create Project</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Create Project</li>
                </ol>
              </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <!-- left column -->

              <!--/.col (left) -->
              <!-- right column -->
              <div class="  col-md-9">
                <!-- Horizontal Form -->

                <!-- /.card -->
                <!-- general form elements disabled -->
                <div class="card card-warning">
                  <div class="card-header">
                    <h3 class="card-title">Edit Your project</h3>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                        <form method="post" action="<?php echo e(route('projects.update',[$project->id])); ?>" id="upload-contacts" enctype="multipart/form-data">

                                <?php echo e(csrf_field()); ?>

                            <!-- text input -->
                            <input type="hidden" name="_method" value="put">

                            <div class="form-group">
                                <label for="project-name">Name<span class="required">*</span></label>
                                <input   placeholder="Enter name"
                                          id="project-name"
                                          required
                                          name="name"
                                          spellcheck="false"
                                          class="form-control"
                                          value="<?php echo e($project->name); ?>"
                                           />
                            </div>


                            <div class="form-group">
                                    <label>Category</label>
                                    <select name= "category" class="form-control">

                                    <option value="Website Hosting">Website Hosting</option>
                                    <option value="SEO">SEO</option>
                                    <option value="Website maintainance">Website maintainance</option>
                                    <option value="Others">Others</option>
                                    </select>
                                </div>


                            




                            <div class="form-group  ">
                                    <input type="submit" class="btn btn-primary pull-6 size-3 col-lg-7  " value="Submit"/>

                            </div>

                        </form>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
              </div>
              <!--/.col (right) -->
            </div>
            <!-- /.row -->
          </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->

      <footer class="main-footer">
            <div class="float-right d-none d-sm-block">
              <b>We are the best</b>
            </div>
            <strong>Copyright &copy;2015 - <?php echo e(date('Y')); ?> <a href="/"><?php echo e(config(' app.name')); ?></a>.</strong> All rights
            reserved.
        </footer>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('../../plugins/jquery/jquery.min.js')); ?>"></script>
      <!-- Bootstrap 4 -->
      <script src="<?php echo e(asset('../../plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
      <!-- FastClick -->
      <script src="<?php echo e(asset('../../plugins/fastclick/fastclick.js')); ?>"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo e(asset('../../dist/js/adminlte.min.js')); ?>"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(asset('../../dist/js/demo.js')); ?>"></script>
    </body>
    </html>



