<aside id="leftsidebar" class="sidebar">
        <!-- User Info -->
        <div class="user-info">
          <div class="image">
            
            </div>

          <div class="info-container">
            <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="button"><?php echo e(auth()->user()->name); ?></div>
            <div class="email"><?php echo e(auth()->user()->email); ?></div>
            
          </div>
        </div>
        <!-- #User Info -->
        <!-- Menu -->
        <div class="menu">
          <ul class="list">
            <li class="active open">
              <a href="home">
                <i class="zmdi zmdi-home"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li>
              <a href="/admin/post">
                <i class="zmdi zmdi-email"></i>
                <span>Inbox</span>
              </a>
            </li>
            <li>
              <a href="Ongoing-SEO-Campaigns">
                <i class="zmdi zmdi-trending-up"></i>
                <span>Ongoing SEO campaigns</span>
              </a>
              </li>
              <li>
               <a href="active-clients">
                <i class="zmdi zmdi-accounts"></i>
                <span>Active Clients</span>
              </a>
            </li>
            <li>
               <a href="expired-services">
                <i class="zmdi zmdi-calendar-close"></i>
                <span>Expired Services</span>
              </a>
            </li>

            <li class="header">MORE FUNCTIONS</li>
            <li>
              <a href="/">
                <i class="zmdi zmdi-chart-donut col-red"></i>
                <span>Add client</span>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="zmdi zmdi-chart-donut col-amber"></i>
                <span>Remove Client</span>
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <i class="zmdi zmdi-chart-donut col-blue"></i>
                <span>Information</span>
              </a>
            </li>
          </ul>
        </div>
        <!-- #Menu -->
      </aside>
