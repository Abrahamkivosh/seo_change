<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    

    <script src="https://use.fontawesome.com/874dbadbd7.js"></script>

    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <!-- Favicon-->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">
  <!--WaitMe Css-->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/waitme/waitMe.css')); ?>" />
  <!-- Custom Css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/color_skins.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/authentication.css')); ?>">
   <script src="<?php echo e(asset('css/app.css')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/inbox.css')); ?>">



    <script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>
    <!-- Lib Scripts Plugin Js -->
    <script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script>
    <!-- Lib Scripts Plugin Js -->

    <script src="<?php echo e(asset('assets/bundles/countTo.bundle.js')); ?>"></script>
    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo e(asset('assets/bundles/knob.bundle.js')); ?>"></script>
    <!-- Jquery Knob Plugin Js -->
    <script src="<?php echo e(asset('assets/bundles/sparkline.bundle.js')); ?>"></script>
    <!-- Sparkline Plugin Js -->
    <script src="<?php echo e(asset('assets/plugins/waitme/waitMe.js')); ?>"></script>
    <!-- Wait Me Plugin Js -->
    <script src="<?php echo e(asset('assets/js/pages/widgets/infobox/infobox-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
    <!-- Custom Js -->
    <script src="<?php echo e(asset('assets/js/pages/charts/jquery-knob.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/charts/sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/cards/basic.js')); ?>"></script>


    <!-- Scripts -->
    



    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    




</head>



<body class="theme-orange">


    <?php echo $__env->yieldContent('requirements'); ?>
    <?php echo $__env->make('include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Top Bar -->
     <?php echo $__env->yieldContent('nav'); ?>
    <!-- Left Sidebar -->
    <?php echo $__env->yieldContent('aside-left'); ?>
    <!-- Right Sidebar -->
    <?php echo $__env->yieldContent('aside-right'); ?>
    <?php echo $__env->yieldContent('aside-left-mail'); ?>

    <?php echo $__env->yieldContent('user-info'); ?>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
<script>
    $('textarea').ckeditor();
    // $('.textarea').ckeditor(); // if class is prefered.
</script>
</body>
</html>
