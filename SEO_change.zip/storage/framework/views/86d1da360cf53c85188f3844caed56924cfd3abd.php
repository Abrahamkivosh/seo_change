<?php $__env->startSection('requirements'); ?>
<!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <p>Please wait...</p>
            <div class="m-t-30"><img src="assets/images/logo.svg" width="48" height="48" alt="Nexa"></div>
        </div>
    </div>
    <!-- Overlay For Sidebars -->
  <div class="overlay"></div>
  <!-- Search  -->
  <div class="search-bar">
    <div class="search-icon">
      <i class="material-icons">search</i>
    </div>
    <input type="text" placeholder="Explore SEO Kenya...">
    <div class="close-search">
      <i class="material-icons">close</i>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<section class="content home">
    <div class="block-header">
            <div class="row">
              <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>SEO Kenya
                  <small class="text-muted">Welcome to the management dashboard</small>
                </h2>
              </div>
              <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                  <li class="breadcrumb-item">
                    <a href="dashboard.">
                      <i class="zmdi zmdi-home"></i> SEO Kenya</a>
                  </li>
                  <li class="breadcrumb-item active">Admin</li>
                </ul>
              </div>
            </div>
          </div>


          <div class="container-fluid">



          <div class="row clearfix">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                  <div class="header">
                  <p>
                  <p>
                    <h2>Expired SEO Clients Projects</h2>
                    <p>
                    <p>
                    <ul class="header-dropdown m-r--5">
                      <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="zmdi zmdi-more-vert"></i>
                        </a>
                        <ul class="dropdown-menu float-right">
                          <li>
                            <a href="javascript:void(0);">Action</a>
                          </li>
                          <li>
                            <a href="javascript:void(0);">Another action</a>
                          </li>
                          <li>
                            <a href="javascript:void(0);">Something else here</a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                  <div class="body">
                    <div class="table-responsive">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>NAME</th>
                            <th>Website</th>
                            <th>STATUS</th>
                            <th>View Project</th>
                            <th>START DATE</th>
                            <th>END DATE</th>
                            <th>MONTHLY SUBSCRIPTION</th>
                          </tr>
                        </thead>
                        <tbody>
                          
                          <form action=" action('AdminsController@expiredservices') }}" method="POST" >
                                
                                    <?php $__currentLoopData = $expiredservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                   
                                    <tr>
                                        <td>1</td>
                                            <td>
                                               <a href="#"> <span><?php echo e($expire -> name); ?></span></a>
                                            </td>
                                            <td><a href="#">
                                                <span class="text text-link"><?php echo e($expire ->website); ?></span></a>
                                            </td>
                                            <td>
                                                
                                                        <?php switch($expire->status):
                                                        case (1): ?>

                                                              PEDDING
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                        <span class="label label-success">   ON GOINING</span>
                                                            <?php break; ?>
                                                            <?php case (3): ?>
                                                            <span class="label label-danger">   EXPIRED</span>
                                                            <?php break; ?>
                                                            <?php case (4): ?>
                                                            <span class="label label-success">   COMPLETED</span>
                                                            <?php break; ?>
                                                            <?php case (5): ?>
                                                            <span class="label label-warning">  WAITING APPROVAL</span>
                                                            <?php break; ?>
                                                           
                                                        <?php default: ?>
                                                        <div class="alert alert-primary" role="alert">
                                                          PROBLEM
                                                        </div>
                                   
                                                    <?php endswitch; ?>
                                                
                                            </td>
                                                <td>
                                                        <div class="col-lg-12"><div class="pull-center">
                                                            <a href="#" class="btn btn-raised btn-primary waves-effect">View Project</a></div>
                                                        </div>
                                                </td>
                                            
                                            <td>
                                                    <span class="text-success">$100</span>
                                            </td>
                                     </tr> 
                                   
                                        
                                   
                                    
                                      
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                    

                          </form>
                         
   
                   
                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>
              </div>
          </div>
          </div>
        </section>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('aside-left'); ?>
<?php echo $__env->make('include.aside-left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
<?php echo $__env->make('include.aside-right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>