@extends('layouts.app')
@section('content')
<body>

    <h1>SEO Kenya</h1>

    </body>
@stop
