<?php

use Faker\Generator as Faker;

$factory->define(App\Project::class, function (Faker $faker) {

    $users = User::all()->lists('id');
    $company = Company::all()->lists('id');
    $status = collect([1, 2, 3, 4, 5]);
    $name =collect('SEO','Maintainace','Web Hosting','Othes');

    // 4 - (retrieved randomly)
    return [
            'name' => $faker->randomElement($name),
            'website' => $faker->domainName(),
            'category' => $faker->randomElement($name),
            'file' =>$faker ->randomElement($name),
            'status' =>  $status->random(),
            // 4 - (retrieved randomly)
            'user_id' => $faker->randomElement($users),
            'company_id' => $faker>randomElement($company)
    ];


});
