<?php

use Faker\Generator as Faker;

$factory->define(App\Admin::class, function (Faker $faker) {
    static $password ;
    return [
            'name' => $faker->name(),
            'email' => $faker->unique()->safeEmail,
            'password' =>  $password ?: $password = bcrypt('secret'),
            'role_id' => '1',
            'coverimage' => 'test image path here',
            'first_name' => $faker->firstName(),
            'last_name' => $faker->name(),
            'middle_name' => 'Ngila'
    ];
});
