<?php

use Illuminate\Database\Seeder;
use Lcobucci\JWT\Claim\Factory;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\User::class,3)->create();

        // App\User::create([

        //     'name' => 'Daniel',
        //     'email' => 'daniel',
        //     'password' => bcrypt('1234567'),
        //     'role_id' => '3',
        //     'coverimage' => 'test image path here',
        //     'first_name' => 'Daniel',
        //     'last_name' => 'John',
        //     'middle_name' => 'Samuel'
        // ] );
        App\User::create([
            'name' => 'Abraham',
            'email' => 'abrahamkivosh@tbxhost.co.uk',
            'password' => bcrypt('Abrakivosh1234'),
            'role_id' => '1',
            'coverimage' => 'test image path here',
            'first_name' => 'Abraham',
            'last_name' => 'Kivondo',
            'middle_name' => 'Ngila'
        ]

    );
    App\User::create([
        'name' => 'Dee Nzioka',
        'email' => 'dee@tbxhost.co.uk',
        'password' => bcrypt('askdee9519'),
        'role_id' => '1',
        'coverimage' => 'test image path here',
        'first_name' => 'Dee',
        'last_name' => 'Nzioka',
        'middle_name' => 'Nzioka'
    ]

);
App\User::create([
    'name' => 'Lawis',
    'email' => 'info@tbxhost.co.uk',
    'password' => bcrypt('@Mwangi5651'),
    'role_id' => '1',
    'coverimage' => 'test image path here',
    'first_name' => 'lawis',
    'last_name' => 'mwangi',
    'middle_name' => 'Lawis'
]

);


    }


}
