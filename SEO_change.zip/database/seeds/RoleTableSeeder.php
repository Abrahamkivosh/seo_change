<?php

use Illuminate\Database\Seeder;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        App\Role::create(['name' => '1']);
        App\Role::create(['name' => '3']);
        App\Role::create(['name' => '2']);
    }
}
