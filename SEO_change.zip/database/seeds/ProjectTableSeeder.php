<?php

use Illuminate\Database\Seeder;

class ProjectTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        App\Project::create([
            'name' => 'SEO ',
            'website' => 'www.facebook.com',
            'category' => 'SEO',
            'file' => 'file.zip ',
            'status' => '0',
            'user_id' => '1',
            'company_id' => '1',
        ]

    );
    }
}
