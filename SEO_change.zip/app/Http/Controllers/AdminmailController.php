<?php

namespace App\Http\Controllers;

use App\AdminMail;
use Illuminate\Http\Request;
use App\Admin;

use Illuminate\Support\Facades\Auth;
class AdminmailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function __construct()
     {
         $this->middleware('auth:admin', ['except' => ['']]);
     }
    public function index()
    {
        //
        $posts = AdminMail::orderBy('id', 'DESC')->where('admin_id', Auth::user()->id)->paginate(4);

        return view('admins.mail.mail-inbox')->with('posts', $posts);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admins.mail.mail-compose');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request,
               [
                   'to' => 'required',
                   'subject' => 'required',
                   'body' => 'required',
               ]);
        $posts = new AdminMail();
        $posts->to = $request->input('to');
        $posts->subject = $request->input('subject');
        $posts->body = $request->input('body');
        $posts->admin_id = Auth()->user()->id;
        $posts->save();

        return redirect('/admin/post')->with('success', 'Mail sent successfuly');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdminMail  $adminMail
     * @return \Illuminate\Http\Response
     */
    public function show( $id)
    {
        //
        $post = AdminMail::find($id);

        return view('admins.mail.mail-single')->with('post', $post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdminMail  $adminMail
     * @return \Illuminate\Http\Response
     */
    public function edit( $id)
    {
        $post = AdminMail::find($id);

        if (Auth()->user()->id !== $post->admin_id) {
            return redirect('/admin/post')->with('error', 'Unable to open');
        } else {
            return view('admins.mail.mail-compose')->with('post', $post);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdminMail  $adminMail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,
        [
            'title' => 'required',
            'body' => 'required',
        ]);
        $posts = AdminMail::find($id);
        $posts->title = $request->input('title');
        $posts->body = $request->input('body');
        $posts->save();

        return redirect('/admin/post')->with('success', 'Mail Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdminMail  $adminMail
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = AdminMail::find($id);

        $post->delete();
        if (Auth()->user()->id !== $post->admin_id) {
            return redirect('/admin/post')->with('error', 'Unable to open');
        }

            //Storage::delete('public/cover_images/'.$post->mycoverimage);

            return redirect('/admin/post')->with('success', 'Post Deleted');

    }
}
