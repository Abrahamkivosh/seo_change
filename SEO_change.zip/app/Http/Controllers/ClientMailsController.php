<?php

namespace App\Http\Controllers;

use App\ClientMails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClientMailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if( Auth::check() ){


            $mails = ClientMails::where('user_id', Auth::user()->id)->get();
           // $mails = ClientMails::all();

             return view('clients.mail.index', ['mails'=> $mails]);
        }
        return view('auth.login');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('clients.mail.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        if(Auth::check()){
            $mail = ClientMails::create([
                'to' => $clientMails->input('to'),
                'subject' => $clientMails->input('subject'),
                'body' => $clientMails->input('body'),
                'user_id' => Auth::user()->id
            ]);


            if($mail){
                return redirect()->route('clients.mail.index', ['mail'=> $clientMails->id])
                ->with('success' , 'Email was sent  successfully');
            }

        }

            return back()->withInput()->with('errors', 'Error sending your email');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ClientMails  $clientMails
     * @return \Illuminate\Http\Response
     */
    public function show(ClientMails $clientMails)
    {
        $mail = ClientMails::find($mail->id);

        return view('clients.mail.show', ['mail'=>$mail]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ClientMails  $clientMails
     * @return \Illuminate\Http\Response
     */
    public function edit(ClientMails $clientMails)
    {
        //

        //
        $mail = ClientMails::find($mail->id);

        return view('clients.mail.edit', ['mail'=>$mail]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ClientMails  $clientMails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClientMails $clientMails)
    {
        //
        $mailUpdate = Company::where('id', $mail->id)
                                ->update([
                                        'to'=> $request->input('to'),
                                        'subject'=> $request->input('subject'),
                                        'body'=> $request->input('body')
                                ]);

      if($mailUpdate){
          return redirect()->route('clients.mail.show', ['mail'=> $mail->id])
          ->with('success' , 'Company updated successfully');
      }
      //redirect
      return back()->withInput();


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ClientMails  $clientMails
     * @return \Illuminate\Http\Response
     */
    public function destroy(ClientMails $clientMails)
    {
        //
    }
}
