<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpKernel\EventListener\ValidateRequestListener;
use Auth;

class AdminLoginController extends Controller
{
    public function __construct()
    {
        $this ->middleware('guest:admin');

    }
    public function showloginform(){

        return view('auth/admin-login');
    }
    public function login(request $request){
        //validate inputs
        $this->validate($request,[
            'email' => 'required|email',
            'password' => 'required|min:6'

        ]
        );
        //adept to login user #endregion

       if( Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request ->password],$request ->remember)){

        return redirect()->intended(route('admin.dashboard'))->with('sucess','You login as admin');
       }
       return redirect()->back()->withInput( $request->only(['email', 'remember']));

    }
}
