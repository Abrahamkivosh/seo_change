<?php

namespace App\Http\Controllers;

use App\Admin;
use App\Project;
use App\User;
use App\Company;
use App\ProjectUser;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index()
    {
       // $users = User::All()->where('active', 1)->count();
       // $users =   DB::select('select * from users ');
       $countclients = DB::table('users')->count();
       $countprojects = DB::table('projects')->count();
        //dd($users);
        $projects = DB::select('select * from projects');
      // $pass  = array( $countclients,$countprojects,$projects );

        $clients = DB::select('select * from users ');
       $countclients = DB::table('users')->count();
       // return view('admins.home',[$countclients,$countclients]);
        return view('admins.home', ['clients'=> $clients], ['projects'=> $projects])->with('countprojects',$countprojects);
        //->with('countclients', $countclients);


    }
    public function ongoingseocampaigns(){
        $projects = DB::select('select * from projects  projects where status != 3');
        return view('admins.Ongoing-SEO-Campaigns')->with('projects', $projects);
    }
    public function expiredservices(){
      
       $expiredservices = DB::select('select * from projects where status = 3');
      
   
        return view('admins.expired-services')->with('expiredservices',$expiredservices);
    }
    public function activeclient()
    {
        //
        $clients = DB::select('select * from users ');
        $projects = DB::select('select * from projects  projects where status != 3');
        return  view('admins.active-clients',['clients'=> $clients])->with('projects', $projects);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        // $projects = DB::select('select * from projects');
        // return  view('admins.home')->with('projects', $projects);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(Admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Admin $admin)
    {
        //
    }
}
