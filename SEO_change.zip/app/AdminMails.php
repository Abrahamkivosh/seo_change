<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations;

class AdminMail extends Model
{
    //You can change table name to that in DB
    protected $table = 'admin_mail';
    //primary '' => , like that in database
    public $primarykey = 'id';
    //timestamps

    public $timestamps = true;
    protected $guarded = [];

    //creating relationship
    public function admins()
    {
        return $this->belongsTo('App\Admin');
    }
}
